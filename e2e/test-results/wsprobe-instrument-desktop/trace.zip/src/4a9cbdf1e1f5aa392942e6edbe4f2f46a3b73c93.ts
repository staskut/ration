import { expect, test } from "./fixtures";

test("instrument", async ({ planner, follower }) => {
  const log: string[] = [];
  follower.on("websocket", (ws) => {
    log.push(`WS OPEN ${Date.now() % 100000}`);
    ws.on("framereceived", (f) => log.push(`FRAME ${Date.now() % 100000} ${String(f.payload).slice(0, 90)}`));
    ws.on("close", () => log.push(`WS CLOSE ${Date.now() % 100000}`));
  });
  follower.on("requestfinished", (r) => {
    if (r.url().includes("/api/today")) log.push(`GET today ${Date.now() % 100000} ${r.url().split("?")[1] ?? ""}`);
  });

  await follower.goto("/");
  const empty = follower.getByText("На этот день ничего не запланировано");
  for (let i = 0; i < 7; i += 1) {
    if (await empty.waitFor({ state: "visible", timeout: 3000 }).then(() => true).catch(() => false)) break;
    const tm = follower.getByLabel("Завтра");
    if (!(await tm.isVisible().catch(() => false))) break;
    await tm.click();
  }
  log.push(`--- on empty day ${Date.now() % 100000} ---`);

  await planner.locator("nav").getByRole("button", { name: "План" }).click();
  const lastDay = planner.locator("#day-6");
  await lastDay.scrollIntoViewIfNeeded();
  await lastDay.getByRole("button", { name: "+" }).nth(3).click();
  const picker = lastDay.locator("select").nth(1);
  await expect(picker).toBeVisible();
  await picker.selectOption({ index: 1 });
  log.push(`--- planner selected ${Date.now() % 100000} ---`);

  const hidden = await empty.waitFor({ state: "hidden", timeout: 15000 }).then(() => true).catch(() => false);
  log.push(`--- hidden=${hidden} ${Date.now() % 100000} ---`);
  console.log("\n" + log.join("\n"));
  expect(hidden).toBe(true);
});
